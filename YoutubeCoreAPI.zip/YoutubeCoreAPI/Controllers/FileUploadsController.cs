﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting.Internal;
using Microsoft.AspNetCore.Hosting;
using YoutubeCoreAPI.Models;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Auth.OAuth2.Flows;
using Google.Apis.Auth.OAuth2.Responses;
using Google.Apis.Services;
using Google.Apis.Upload;
using Google.Apis.YouTube.v3;
using Google.Apis.YouTube.v3.Data;
using System.Reflection;
using System.Threading;

namespace YoutubeCoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FileUploadsController : ControllerBase
    {
        public YoutubeAPIContext youtubeAPIContext;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public FileUploadsController(YoutubeAPIContext yt)
        {
            youtubeAPIContext = yt;
        }
        private readonly IHostingEnvironment hostingEnvironment;

        [HttpGet("UploadVideo")]
        public async void UploadToYoutube()
        {
            var credential = await YouTubeActions.Run();
            var id = await this.InsertVideo(credential);
            this.youtubeAPIContext.FileUploads.Add(new FileUploads()
            {
                FilePath = "From Youtube",
                FileID = id
            });
            youtubeAPIContext.SaveChanges();
        }
        [HttpPost("UploadImage")]
        public async Task<string> UploadFile([FromBody]ICollection<IFormFile> files)
        {
            try
            {
                foreach (var file in files)
                {
                    string fName = file.FileName;
                    string path = Path.Combine(hostingEnvironment.ContentRootPath, "Images/" + file.FileName);
                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }
                    this.youtubeAPIContext.FileUploads.Add(new FileUploads()
                    {
                        FilePath = path,
                        FileID = 0
                    });
                    youtubeAPIContext.SaveChanges();

                }
            }
            catch(Exception ex)
            {
                return "The error occured while Upload.." + ex;
            }
            return "Success";
        }
        [HttpGet("Insert")]
        public async Task<int> InsertVideo(UserCredential credential)
        {
            var youtubeService = new YouTubeService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = Assembly.GetExecutingAssembly().GetName().Name
            });

            var video = new Video();
            video.Snippet = new VideoSnippet();
            video.Snippet.Title = "My Test Video For Core API and angular";
            video.Snippet.Description = "Test Description";
            video.Snippet.Tags = new string[] { "Angular", "CoreAPI" };
            video.Snippet.CategoryId = "22";
            video.Status = new VideoStatus();
            video.Status.PrivacyStatus = "public";
            string _path = Path.Combine(Directory.GetCurrentDirectory(), "sample-mp4-file.mp4");
            // Replace with actual file from front end(videos format)
            using (var fileStream = new FileStream(_path, FileMode.Open))
            {
                var videosInsertRequest = youtubeService.Videos.Insert(video, "snippet,status", fileStream, "video/*");
                var id = await videosInsertRequest.UploadAsync();

            }
            return Convert.ToInt32(video.Id);
        }
    }
}