﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace YoutubeCoreAPI.Models
{
    [Table("FileUploads")]
    public class FileUploads
    {
        [Key]
        public int FileID { get; set; }
        public string FilePath { get; set; }
        public int VideoID { get; set; }
    }
}
