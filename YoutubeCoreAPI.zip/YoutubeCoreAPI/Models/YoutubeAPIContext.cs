﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace YoutubeCoreAPI.Models
{
    public class YoutubeAPIContext : DbContext
    {
        public YoutubeAPIContext(DbContextOptions options) : base(options)
        {
        }

       public DbSet<FileUploads> FileUploads { get; set; }
    }
}
